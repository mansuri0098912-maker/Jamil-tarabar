Jamil Tarabar MVP

Files:
- app.py : initial Streamlit application
- requirements.txt : dependencies

Run:
pip install -r requirements.txt
streamlit run app.py
